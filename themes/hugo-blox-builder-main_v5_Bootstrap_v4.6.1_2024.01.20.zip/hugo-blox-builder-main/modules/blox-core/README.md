# blox-core

Core Hugo Blox Builder utilities and integrations.

A module for commonalities between the `blox-bootstrap` and `blox-tailwind` UIs.

## Uses

Used in the following modules:

- blox-seo
- blox-bootstrap
- blox-tailwind
