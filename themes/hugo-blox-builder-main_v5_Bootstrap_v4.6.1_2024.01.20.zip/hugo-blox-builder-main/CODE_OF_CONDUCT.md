# Code of Conduct

We want to foster a positive, inclusive, and welcoming environment 💜

We expect you to follow our [Code of Conduct](https://docs.hugoblox.com/reference/contribute/) to fulfil this goal.
